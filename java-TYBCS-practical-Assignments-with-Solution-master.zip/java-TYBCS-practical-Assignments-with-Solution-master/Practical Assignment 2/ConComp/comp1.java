package ConComp;

public class comp1 {

    public void displaycomp(String s1, String s2){

        System.out.println("Compared String : " +s1.compareTo(s2));
    }
}
