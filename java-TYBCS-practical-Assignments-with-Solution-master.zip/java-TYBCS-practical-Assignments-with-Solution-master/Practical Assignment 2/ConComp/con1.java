package ConComp;

public class con1 {
    public void displaycon(String s1, String s2) {
        
        System.out.println("Concatenated String : " + s1.concat(s2));
    }
}
